var waitFor = require('waitFor');

waitFor('.sample-component', function() {
  console.log('Sample Component');
});