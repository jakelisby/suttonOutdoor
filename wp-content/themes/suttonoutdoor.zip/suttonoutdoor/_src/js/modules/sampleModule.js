var waitFor = require('waitFor');

waitFor('.sample-module', function() {
  console.log('Sample Module');
});