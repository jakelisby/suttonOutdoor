## Changelog

**04/27/2015**
* Added changelog file
* Modified partials/README.md
