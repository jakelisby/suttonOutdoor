<?php
	// Before you code, please read: http://codex.wordpress.org/Template_Hierarchy
	// Remember that any missing templates will redirect here, so use it wisely!
	get_header();
?>
<?php get_footer(); ?>