<?php

// --------------------------------
// Register Custom Image Crops
// --------------------------------

// if ( function_exists( 'add_image_size' ) ) {
//   add_image_size( 'crop-name', 300, 300, true );
// }
