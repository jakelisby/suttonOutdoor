<?php
define('FILE_CACHE_DIRECTORY', '../../../../timthumb-cache');